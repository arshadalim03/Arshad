package com.capgemini.ui;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.capgemini.dao.CustomerDAO;
import com.capgemini.dao.WalletDAOJPAImpl;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidInputException;
import com.capgemini.service.CustomerService;
import com.capgemini.service.CustomerServiceImpl;

public class JPAClient {

	public static void main(String[] args) throws InsufficientBalanceException, InvalidInputException {
/*		EntityManagerFactory factory = Persistence.createEntityManagerFactory("WALLET");
		EntityManager em = factory.createEntityManager();
		
		CustomerDAO dao = new WalletDAOJPAImpl(em);
*/		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("springjpaconfig.xml");
		
		CustomerService service = ctx.getBean("service",CustomerService.class);
		
		//service.setCustomerDAO(dao);
		
		System.out.println(service.createAccount("Jalim", "1234567890", new BigDecimal(4000)));
		
		System.out.println("Happy BirthD Manohar!!!!");
		
		System.out.println(service.showBalance("1234567890"));
		ctx.close();
		
	}

}













