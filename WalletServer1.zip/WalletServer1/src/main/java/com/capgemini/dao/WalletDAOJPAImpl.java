package com.capgemini.dao;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capgemini.bean.Customer;



public class WalletDAOJPAImpl implements CustomerDAO {

		private EntityManager em;
		
	public WalletDAOJPAImpl(EntityManager em) {
			super();
			this.em = em;
		}

	@Override
	public Customer save(Customer customer) {
		em.getTransaction().begin();
		Customer c = em.merge(customer);
		em.getTransaction().commit();
		return c;
	}

	@Override
	public Customer findByMobileNumber(String mobileNumber) {
		TypedQuery<Customer> query = em.createQuery("Select c from Customer c where c.mobileNumber=:mobileNumber",Customer.class);
		System.out.println(query);
		query.setParameter("mobileNumber", mobileNumber);
		
		return query.getSingleResult();
		//return query.getResultList();
		//return null;
	}

	@Override
	public Customer updateCustomerWalletBalance(String mobileNumber, BigDecimal amount) {
		
		return null;
	}

}
