package com.capgemini.service;

import java.math.BigDecimal;

import com.capgemini.bean.Customer;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidInputException;

public interface CustomerService {
	
	public Customer createAccount(String customerName,String mobileNumber, BigDecimal balance) throws InsufficientBalanceException, InvalidInputException;
	public Customer fundTransfer(String sourceMobileNumber, String destinationMobileNumber, BigDecimal balance) throws InvalidInputException, InsufficientBalanceException;
	public Customer depositAmount(String mobileNumber, BigDecimal balance) throws InvalidInputException;
	public Customer showBalance(String mobileNumber) throws InvalidInputException;
	public Customer showTransactions(String mobileNumber);
	
	
}
