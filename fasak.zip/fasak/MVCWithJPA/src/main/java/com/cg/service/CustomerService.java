package com.cg.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.bean.Customer;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InvalidInputException;

public interface CustomerService {
	
	public Customer createAccount(String customerName,String mobileNumber, BigDecimal balance) throws InsufficientBalanceException, InvalidInputException;
	public Customer fundTransfer(String sourceMobileNumber, String destinationMobileNumber, BigDecimal balance) throws InvalidInputException, InsufficientBalanceException;
	public Customer depositAmount(String mobileNumber, BigDecimal balance) throws InvalidInputException;
	public Customer showBalance(String mobileNumber) throws InvalidInputException;
	public List<String> showTransactions(String mobileNumber) throws InvalidInputException;
	
	
}
