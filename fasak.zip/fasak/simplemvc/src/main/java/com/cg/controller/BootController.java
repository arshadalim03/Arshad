
package com.cg.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BootController {

	@RequestMapping("/")
	public String bootMe() {
		
		return "Spring Boot is up & runing!";
	}
	
	@RequestMapping("/message")
	public Test getComplexMessage() {
		Test t = new Test();
		t.setText("blaha blaha");
		return t;
	}
}

class Test{
	
private String text;

public String getText() {
	return text;
}

public void setText(String text) {
	this.text = text;
}


}