package com.cg.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Customer;
import com.cg.exception.InsufficientBalanceException;
import com.cg.exception.InvalidInputException;
import com.cg.service.CustomerService;

@RestController
public class WalletController {


	@Autowired
	private CustomerService service;
	
	@RequestMapping("/")
	public String welcome() {
		return "Wallet application reporting to the duty..";
	}
	
	@RequestMapping(value="/create", method=RequestMethod.POST)
	public Customer createAccount(String name, String mobile, BigDecimal amount) throws InsufficientBalanceException, InvalidInputException {
		
		return service.createAccount(name, mobile, amount); 
	}
	
	@RequestMapping("/showBalance")
	public Customer showBalance(String mobile) throws InvalidInputException {
		return service.showBalance(mobile);
	}
}

